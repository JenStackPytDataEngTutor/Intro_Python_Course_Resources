

# show_module_path.py
import sys
for path in sys.path:
    print(path)
