

from time import *
print(timezone)
print(asctime())
sleep(3)
print(asctime())
