

import say_hi2
say_hi2.say_hi()
