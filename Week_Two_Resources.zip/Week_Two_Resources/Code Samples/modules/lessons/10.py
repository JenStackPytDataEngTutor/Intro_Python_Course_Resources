

import say_hi3
say_hi3.say_hi()
