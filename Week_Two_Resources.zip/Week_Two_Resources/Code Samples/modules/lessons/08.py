

import say_hi
say_hi.say_hi()
