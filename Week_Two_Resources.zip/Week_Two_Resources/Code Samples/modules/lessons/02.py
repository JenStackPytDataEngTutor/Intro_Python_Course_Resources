

from time import asctime
print(asctime())
