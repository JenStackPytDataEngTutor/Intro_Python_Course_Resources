def sub_report():
	print("Hey Im a function inside mysubscript")