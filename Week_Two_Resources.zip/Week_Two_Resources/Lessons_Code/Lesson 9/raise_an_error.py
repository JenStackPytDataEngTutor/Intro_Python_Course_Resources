def raise_an_error(error): 
    raise error 
   
raise_an_error(ValueError) 